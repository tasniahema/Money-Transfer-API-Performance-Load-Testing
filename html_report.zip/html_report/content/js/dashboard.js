/*
   Licensed to the Apache Software Foundation (ASF) under one or more
   contributor license agreements.  See the NOTICE file distributed with
   this work for additional information regarding copyright ownership.
   The ASF licenses this file to You under the Apache License, Version 2.0
   (the "License"); you may not use this file except in compliance with
   the License.  You may obtain a copy of the License at

       http://www.apache.org/licenses/LICENSE-2.0

   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
   See the License for the specific language governing permissions and
   limitations under the License.
*/
var showControllersOnly = false;
var seriesFilter = "";
var filtersOnlySampleSeries = true;

/*
 * Add header in statistics table to group metrics by category
 * format
 *
 */
function summaryTableHeader(header) {
    var newRow = header.insertRow(-1);
    newRow.className = "tablesorter-no-sort";
    var cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Requests";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 3;
    cell.innerHTML = "Executions";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 7;
    cell.innerHTML = "Response Times (ms)";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 1;
    cell.innerHTML = "Throughput";
    newRow.appendChild(cell);

    cell = document.createElement('th');
    cell.setAttribute("data-sorter", false);
    cell.colSpan = 2;
    cell.innerHTML = "Network (KB/sec)";
    newRow.appendChild(cell);
}

/*
 * Populates the table identified by id parameter with the specified data and
 * format
 *
 */
function createTable(table, info, formatter, defaultSorts, seriesIndex, headerCreator) {
    var tableRef = table[0];

    // Create header and populate it with data.titles array
    var header = tableRef.createTHead();

    // Call callback is available
    if(headerCreator) {
        headerCreator(header);
    }

    var newRow = header.insertRow(-1);
    for (var index = 0; index < info.titles.length; index++) {
        var cell = document.createElement('th');
        cell.innerHTML = info.titles[index];
        newRow.appendChild(cell);
    }

    var tBody;

    // Create overall body if defined
    if(info.overall){
        tBody = document.createElement('tbody');
        tBody.className = "tablesorter-no-sort";
        tableRef.appendChild(tBody);
        var newRow = tBody.insertRow(-1);
        var data = info.overall.data;
        for(var index=0;index < data.length; index++){
            var cell = newRow.insertCell(-1);
            cell.innerHTML = formatter ? formatter(index, data[index]): data[index];
        }
    }

    // Create regular body
    tBody = document.createElement('tbody');
    tableRef.appendChild(tBody);

    var regexp;
    if(seriesFilter) {
        regexp = new RegExp(seriesFilter, 'i');
    }
    // Populate body with data.items array
    for(var index=0; index < info.items.length; index++){
        var item = info.items[index];
        if((!regexp || filtersOnlySampleSeries && !info.supportsControllersDiscrimination || regexp.test(item.data[seriesIndex]))
                &&
                (!showControllersOnly || !info.supportsControllersDiscrimination || item.isController)){
            if(item.data.length > 0) {
                var newRow = tBody.insertRow(-1);
                for(var col=0; col < item.data.length; col++){
                    var cell = newRow.insertCell(-1);
                    cell.innerHTML = formatter ? formatter(col, item.data[col]) : item.data[col];
                }
            }
        }
    }

    // Add support of columns sort
    table.tablesorter({sortList : defaultSorts});
}

$(document).ready(function() {

    // Customize table sorter default options
    $.extend( $.tablesorter.defaults, {
        theme: 'blue',
        cssInfoBlock: "tablesorter-no-sort",
        widthFixed: true,
        widgets: ['zebra']
    });

    var data = {"OkPercent": 98.0, "KoPercent": 2.0};
    var dataset = [
        {
            "label" : "FAIL",
            "data" : data.KoPercent,
            "color" : "#FF6347"
        },
        {
            "label" : "PASS",
            "data" : data.OkPercent,
            "color" : "#9ACD32"
        }];
    $.plot($("#flot-requests-summary"), dataset, {
        series : {
            pie : {
                show : true,
                radius : 1,
                label : {
                    show : true,
                    radius : 3 / 4,
                    formatter : function(label, series) {
                        return '<div style="font-size:8pt;text-align:center;padding:2px;color:white;">'
                            + label
                            + '<br/>'
                            + Math.round10(series.percent, -2)
                            + '%</div>';
                    },
                    background : {
                        opacity : 0.5,
                        color : '#000'
                    }
                }
            }
        },
        legend : {
            show : true
        }
    });

    // Creates APDEX table
    createTable($("#apdexTable"), {"supportsControllersDiscrimination": true, "overall": {"data": [0.838, 500, 1500, "Total"], "isController": false}, "titles": ["Apdex", "T (Toleration threshold)", "F (Frustration threshold)", "Label"], "items": [{"data": [0.45, 500, 1500, "user-create(Customer 1)"], "isController": false}, {"data": [1.0, 500, 1500, "Payment-Customer1-to-Merchant"], "isController": false}, {"data": [0.9, 500, 1500, "search-user-by-id"], "isController": false}, {"data": [1.0, 500, 1500, "Send-money-Customer1-to-Customer2"], "isController": false}, {"data": [1.0, 500, 1500, "balance-check"], "isController": false}, {"data": [0.8, 500, 1500, "Customer2( Login )"], "isController": false}, {"data": [1.0, 500, 1500, "search-user-by-email"], "isController": false}, {"data": [1.0, 500, 1500, "commission-listing"], "isController": false}, {"data": [0.95, 500, 1500, "Withdraw-Customer1-to-Agent"], "isController": false}, {"data": [1.0, 500, 1500, "admin-create-virtual-money"], "isController": false}, {"data": [0.5, 500, 1500, "Login (Admin)"], "isController": false}, {"data": [1.0, 500, 1500, "transaction-Details"], "isController": false}, {"data": [1.0, 500, 1500, "commission-create"], "isController": false}, {"data": [0.9, 500, 1500, "Deposit (SYSTEM → CUSTOMER)"], "isController": false}, {"data": [0.9, 500, 1500, "Deposit (SYSTEM -> AGENT )"], "isController": false}, {"data": [1.0, 500, 1500, "Deposit (AGENT → Customer1)"], "isController": false}, {"data": [1.0, 500, 1500, "system-virtual-balance"], "isController": false}, {"data": [0.45, 500, 1500, "user-create(Agent)"], "isController": false}, {"data": [0.5, 500, 1500, "Customer1( Login )"], "isController": false}, {"data": [0.5, 500, 1500, "user-create(Merchant)"], "isController": false}, {"data": [1.0, 500, 1500, "Debug Sampler"], "isController": false}, {"data": [0.85, 500, 1500, "Agent( Login )"], "isController": false}, {"data": [0.5, 500, 1500, "user-create(Customer 2)"], "isController": false}, {"data": [0.8, 500, 1500, "get-all-user"], "isController": false}, {"data": [0.95, 500, 1500, "transaction-history"], "isController": false}]}, function(index, item){
        switch(index){
            case 0:
                item = item.toFixed(3);
                break;
            case 1:
            case 2:
                item = formatDuration(item);
                break;
        }
        return item;
    }, [[0, 0]], 3);

    // Create statistics table
    createTable($("#statisticsTable"), {"supportsControllersDiscrimination": true, "overall": {"data": ["Total", 250, 5, 2.0, 365.9239999999997, 0, 1492, 174.0, 958.9000000000001, 1210.8999999999992, 1444.0900000000004, 15.085686700458606, 18.730353250211202, 9.428436330859281], "isController": false}, "titles": ["Label", "#Samples", "FAIL", "Error %", "Average", "Min", "Max", "Median", "90th pct", "95th pct", "99th pct", "Transactions/s", "Received", "Sent"], "items": [{"data": ["user-create(Customer 1)", 10, 1, 10.0, 904.6, 233, 1340, 959.5, 1336.3, 1340.0, 1340.0, 2.067397146991937, 1.0623675573702709, 1.6967192991523672], "isController": false}, {"data": ["Payment-Customer1-to-Merchant", 10, 0, 0.0, 128.8, 109, 151, 130.0, 150.4, 151.0, 151.0, 2.3775558725630055, 0.8219284950071326, 1.6624316452686636], "isController": false}, {"data": ["search-user-by-id", 10, 0, 0.0, 247.79999999999998, 99, 526, 165.5, 524.5, 526.0, 526.0, 3.171582619727244, 1.9512666508087535, 1.9295859102442119], "isController": false}, {"data": ["Send-money-Customer1-to-Customer2", 10, 0, 0.0, 158.89999999999998, 107, 299, 135.0, 295.6, 299.0, 299.0, 2.293052052281587, 0.783758025682183, 1.6257380761293283], "isController": false}, {"data": ["balance-check", 10, 0, 0.0, 109.5, 95, 128, 109.5, 127.4, 128.0, 128.0, 2.093364036005861, 0.6848407734980113, 1.3022196200544274], "isController": false}, {"data": ["Customer2( Login )", 10, 0, 0.0, 468.70000000000005, 327, 580, 476.5, 577.3, 580.0, 580.0, 1.996007984031936, 1.3781031686626748, 0.7718937125748503], "isController": false}, {"data": ["search-user-by-email", 10, 0, 0.0, 180.89999999999998, 102, 280, 164.0, 277.7, 280.0, 280.0, 2.999400119976005, 1.2097189937012598, 1.880483278344331], "isController": false}, {"data": ["commission-listing", 10, 0, 0.0, 143.0, 100, 197, 145.5, 195.70000000000002, 197.0, 197.0, 4.401408450704226, 17.725984815140848, 2.9915823063380285], "isController": false}, {"data": ["Withdraw-Customer1-to-Agent", 10, 0, 0.0, 201.79999999999995, 113, 676, 141.0, 631.2000000000002, 676.0, 676.0, 2.027163997567403, 0.6794166835597, 1.457024123251571], "isController": false}, {"data": ["admin-create-virtual-money", 10, 0, 0.0, 196.7, 106, 454, 169.0, 434.50000000000006, 454.0, 454.0, 3.5124692658939236, 1.2074113101510362, 2.5314475763962068], "isController": false}, {"data": ["Login (Admin)", 10, 0, 0.0, 1090.4, 652, 1492, 1056.5, 1489.3, 1492.0, 1492.0, 1.7550017550017551, 1.1928527553527553, 0.6307037557037557], "isController": false}, {"data": ["transaction-Details", 10, 0, 0.0, 134.2, 100, 336, 112.5, 315.30000000000007, 336.0, 336.0, 2.032520325203252, 1.246506605691057, 1.2564310213414633], "isController": false}, {"data": ["commission-create", 10, 0, 0.0, 137.29999999999998, 112, 173, 129.0, 172.3, 173.0, 173.0, 4.531037607612143, 2.1991461826008156, 3.5177489238785684], "isController": false}, {"data": ["Deposit (SYSTEM → CUSTOMER)", 10, 1, 10.0, 178.6, 98, 417, 139.5, 399.1, 417.0, 417.0, 3.772161448509996, 1.4812364437947945, 2.706820539419087], "isController": false}, {"data": ["Deposit (SYSTEM -> AGENT )", 10, 1, 10.0, 186.9, 110, 389, 148.5, 385.5, 389.0, 389.0, 3.6900369003690034, 1.2644862776752768, 2.6298720018450186], "isController": false}, {"data": ["Deposit (AGENT → Customer1)", 10, 0, 0.0, 141.9, 111, 240, 125.5, 234.50000000000003, 240.0, 240.0, 2.0312817387771687, 0.8228277980905951, 1.4718857911842373], "isController": false}, {"data": ["system-virtual-balance", 10, 0, 0.0, 135.9, 98, 210, 124.0, 207.20000000000002, 210.0, 210.0, 4.277159965782721, 1.3700278015397775, 2.836124625748503], "isController": false}, {"data": ["user-create(Agent)", 10, 1, 10.0, 866.3000000000001, 263, 1365, 882.0, 1339.1000000000001, 1365.0, 1365.0, 1.8642803877703207, 0.9514384088366891, 1.5190972222222223], "isController": false}, {"data": ["Customer1( Login )", 10, 0, 0.0, 680.1, 513, 1054, 619.0, 1034.0, 1054.0, 1054.0, 1.9607843137254901, 1.3537837009803924, 0.7199754901960784], "isController": false}, {"data": ["user-create(Merchant)", 10, 1, 10.0, 854.8, 175, 1402, 827.0, 1380.1000000000001, 1402.0, 1402.0, 2.000400080016003, 1.0367307836567314, 1.647595144028806], "isController": false}, {"data": ["Debug Sampler", 10, 0, 0.0, 1.6000000000000003, 0, 8, 1.0, 7.400000000000002, 8.0, 8.0, 2.2276676319893074, 10.78939490977946, 0.0], "isController": false}, {"data": ["Agent( Login )", 10, 0, 0.0, 443.4, 333, 572, 426.0, 569.7, 572.0, 572.0, 1.993620414673046, 1.3628264553429028, 0.7359262858851675], "isController": false}, {"data": ["user-create(Customer 2)", 10, 0, 0.0, 990.6999999999999, 701, 1256, 964.5, 1255.6, 1256.0, 1256.0, 1.839587932303164, 1.0473435200515084, 1.566524098601913], "isController": false}, {"data": ["get-all-user", 10, 0, 0.0, 354.1, 113, 724, 251.5, 719.8, 724.0, 724.0, 2.5278058645096055, 13.714827951213348, 1.5206332153690596], "isController": false}, {"data": ["transaction-history", 10, 0, 0.0, 211.2, 109, 546, 134.5, 525.7, 546.0, 546.0, 2.0345879959308237, 13.461263351983723, 1.2875127161749746], "isController": false}]}, function(index, item){
        switch(index){
            // Errors pct
            case 3:
                item = item.toFixed(2) + '%';
                break;
            // Mean
            case 4:
            // Mean
            case 7:
            // Median
            case 8:
            // Percentile 1
            case 9:
            // Percentile 2
            case 10:
            // Percentile 3
            case 11:
            // Throughput
            case 12:
            // Kbytes/s
            case 13:
            // Sent Kbytes/s
                item = item.toFixed(2);
                break;
        }
        return item;
    }, [[0, 0]], 0, summaryTableHeader);

    // Create error table
    createTable($("#errorsTable"), {"supportsControllersDiscrimination": false, "titles": ["Type of error", "Number of errors", "% in errors", "% in all samples"], "items": [{"data": ["400/Bad Request", 1, 20.0, 0.4], "isController": false}, {"data": ["422/Unprocessable Content", 3, 60.0, 1.2], "isController": false}, {"data": ["404/Not Found", 1, 20.0, 0.4], "isController": false}]}, function(index, item){
        switch(index){
            case 2:
            case 3:
                item = item.toFixed(2) + '%';
                break;
        }
        return item;
    }, [[1, 1]]);

        // Create top5 errors by sampler
    createTable($("#top5ErrorsBySamplerTable"), {"supportsControllersDiscrimination": false, "overall": {"data": ["Total", 250, 5, "422/Unprocessable Content", 3, "400/Bad Request", 1, "404/Not Found", 1, "", "", "", ""], "isController": false}, "titles": ["Sample", "#Samples", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors", "Error", "#Errors"], "items": [{"data": ["user-create(Customer 1)", 10, 1, "422/Unprocessable Content", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["Deposit (SYSTEM → CUSTOMER)", 10, 1, "404/Not Found", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": ["Deposit (SYSTEM -> AGENT )", 10, 1, "400/Bad Request", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": ["user-create(Agent)", 10, 1, "422/Unprocessable Content", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": ["user-create(Merchant)", 10, 1, "422/Unprocessable Content", 1, "", "", "", "", "", "", "", ""], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}, {"data": [], "isController": false}]}, function(index, item){
        return item;
    }, [[0, 0]], 0);

});
